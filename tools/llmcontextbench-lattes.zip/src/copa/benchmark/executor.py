from __future__ import annotations

from datetime import datetime

from copa.ai.cache import build_inline_prompt_cache_key
from copa.ai.engine import Engine
from copa.ai.models.base import AIRequest
from copa.ai.runtime import LocalFunctionRuntime, MCPRuntime
from copa.benchmark.models import EvaluationResult, RunResult, RunTiming, RunTrace, RunSpec
from copa.datasets.lattes.mcp_server import LattesMCPServer
from copa.datasets.lattes.tools import LattesToolService
from copa.util.clock import utc_now_iso


def execute_runspec(runspec: RunSpec, engine: Engine) -> RunResult:
    from copa.dataset.provider import DatasetProvider

    provider = DatasetProvider.from_dataset(runspec.dataset)
    context = provider.get_context(runspec.instanceId, runspec.format)
    context_path = provider.get_context_artifact_path(runspec.instanceId, runspec.format)
    instance_dir = provider.get_instance_dir(runspec.instanceId)
    lattes_id = runspec.instanceId
    request_params = dict(runspec.params)
    if runspec.strategy == "inline" and runspec.provider.lower().startswith("openai"):
        request_params.setdefault(
            "prompt_cache_key",
            build_inline_prompt_cache_key(
                model_name=str(runspec.modelName or runspec.params.get("model_name") or ""),
                instance_id=runspec.instanceId,
                format_name=runspec.format,
                context=context,
            ),
        )

    request = AIRequest(
        question=runspec.question,
        context=context,
        provider_name=runspec.provider,
        model_name=str(runspec.params.get("model_name", "")),
        strategy_name=runspec.strategy,
        context_format=runspec.format,
        params=request_params,
        metadata={
            "run_id": runspec.runId,
            "runId": runspec.runId,
            "expId": runspec.experimentId,
            "question_id": runspec.questionId,
            "instance_id": runspec.instanceId,
            "experiment_id": runspec.experimentId,
            "phase": "execution",
            "format": runspec.format,
            "provider": runspec.provider,
            "lattes_id": lattes_id,
            "instance_dir": str(instance_dir.resolve()),
            "question_tags": list(runspec.questionTags),
            "validation_type": runspec.validationType,
            "context_path": str(context_path.resolve()),
        },
    )

    started_at = utc_now_iso()
    start = datetime.fromisoformat(started_at.replace("Z", "+00:00"))
    active_engine = engine
    owned_engine: Engine | None = None
    if runspec.strategy in {"local_function", "local_mcp"}:
        tool_runtime_factories = {}
        if runspec.strategy == "local_function":
            tool_runtime_factories["local_function"] = lambda: LocalFunctionRuntime(
                LattesToolService(contexts_dir=runspec.dataset.contexts)
            )
        if runspec.strategy == "local_mcp":
            tool_runtime_factories["local_mcp"] = lambda: MCPRuntime.for_local_server(
                LattesMCPServer(
                    contexts_dir=runspec.dataset.contexts,
                )
            )
        owned_engine = engine.copy_with_tool_runtime_factories(tool_runtime_factories)
        active_engine = owned_engine
    try:
        ai_result = active_engine.execute(request)
    finally:
        if owned_engine is not None:
            owned_engine.close()
    finished_at = utc_now_iso()
    finish = datetime.fromisoformat(finished_at.replace("Z", "+00:00"))

    is_empty_answer = ai_result.error is None and not (ai_result.answer or "").strip()
    error_message = ai_result.error or ("Model returned empty answer" if is_empty_answer else None)
    run_status = "error" if error_message is not None else "success"

    trace = RunTrace()
    if runspec.trace.enabled:
        trace.aiTrace = ai_result.trace
        if runspec.trace.save_tool_calls:
            trace.toolCalls = ai_result.tool_calls
        native_mcp = ai_result.metadata.get("native_mcp")
        if isinstance(native_mcp, dict):
            trace.nativeMcp = native_mcp
        server_mcp = ai_result.metadata.get("server_mcp")
        if isinstance(server_mcp, list):
            trace.serverMcp = [item for item in server_mcp if isinstance(item, dict)]
        if runspec.trace.save_raw_response:
            trace.rawResponse = ai_result.raw_response
        if runspec.trace.save_errors:
            trace.error = error_message

    usage = ai_result.usage if runspec.trace.save_usage or run_status == "error" else {}
    metrics_summary = _build_metrics_summary(
        ai_trace=trace.aiTrace,
        strategy=runspec.strategy,
    )
    result = RunResult(
        runId=runspec.runId,
        experimentId=runspec.experimentId,
        dataset=runspec.dataset,
        questionId=runspec.questionId,
        question=runspec.question,
        questionTemplate=runspec.questionTemplate,
        questionTags=list(runspec.questionTags),
        validationType=runspec.validationType,
        contextBlock=list(runspec.contextBlock),
        parameters=dict(runspec.parameters),
        instanceId=runspec.instanceId,
        provider=runspec.provider,
        modelId=runspec.modelId,
        modelName=runspec.modelName,
        strategy=runspec.strategy,
        format=runspec.format,
        repeatIndex=runspec.repeatIndex,
        outputRoot=runspec.outputRoot,
        answer=ai_result.answer,
        status=run_status,
        errorMessage=error_message,
        timing=RunTiming(
            startedAt=started_at,
            finishedAt=finished_at,
            durationMs=max(0, int((finish - start).total_seconds() * 1000)),
        ),
        usage=usage,
        metricsSummary=metrics_summary,
        trace=trace,
        evaluation=EvaluationResult(),
        metadata=runspec.metadata,
    )
    return result


def _build_metrics_summary(*, ai_trace: dict[str, object], strategy: str) -> dict[str, int | None]:
    metrics = ai_trace.get("metrics", {}) if isinstance(ai_trace, dict) else {}
    if not isinstance(metrics, dict):
        metrics = {}
    summary: dict[str, int | None] = {
        "totalDurationMs": _as_int(metrics.get("totalDurationMs")),
        "strategyDurationMs": _as_int(metrics.get("strategyDurationMs")),
        "modelDurationMs": _as_int(metrics.get("modelDurationMs")),
        "toolDurationMs": _as_int(metrics.get("toolDurationMs")),
        "benchmarkDurationMsEstimated": _as_int(metrics.get("benchmarkDurationMsEstimated")),
        "loopControlDurationMsEstimated": _as_int(metrics.get("loopControlDurationMsEstimated")),
        "modelCalls": _as_int(metrics.get("modelCalls")),
        "mcpToolCalls": _as_int(metrics.get("mcpToolCalls")),
        "toolCalls": _as_int(metrics.get("toolCalls")),
        "functionCalls": _as_int(metrics.get("functionCalls")),
        "steps": _as_int(metrics.get("steps")),
        "retryCount": _as_int(metrics.get("retryCount")),
        "inputTokens": _as_int(metrics.get("inputTokens")),
        "outputTokens": _as_int(metrics.get("outputTokens")),
        "totalTokens": _as_int(metrics.get("totalTokens")),
        "totalTokensEstimated": _as_int(metrics.get("totalTokensEstimated")),
        "cachedInputTokens": _as_int(metrics.get("cachedInputTokens")),
        "cacheReadInputTokens": _as_int(metrics.get("cacheReadInputTokens")),
        "cacheCreationInputTokens": _as_int(metrics.get("cacheCreationInputTokens")),
        "questionTokensEstimated": _as_int(metrics.get("questionTokensEstimated")),
        "estimatedInputTokens": _as_int(metrics.get("estimatedInputTokens")),
        "estimatedOutputTokens": _as_int(metrics.get("estimatedOutputTokens")),
        "reservedTokens": _as_int(metrics.get("reservedTokens")),
        "contextChars": _as_int(metrics.get("contextChars")),
        "contextBytes": _as_int(metrics.get("contextBytes")),
        "questionChars": _as_int(metrics.get("questionChars")),
        "promptChars": _as_int(metrics.get("promptChars")),
        "rateLimitWaitMs": _as_int(metrics.get("rateLimitWaitMs")),
        "retrySleepMs": _as_int(metrics.get("retrySleepMs")),
    }
    if strategy == "inline":
        summary["toolDurationMs"] = 0
        summary["toolCalls"] = 0
        summary["functionCalls"] = 0
        summary["mcpToolCalls"] = 0
    return summary


def _as_int(value: object) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return None
