"""Strategy adapters."""
