"""AI layer abstractions."""
