"""Model adapters."""
